public class Cylinder {
    private static final double PI = 3.14;
    double radius;
    double height;
    String color;

    public Cylinder(double radius,double height,String color){
        this.radius = radius;
        this.height = height;
        this.color = color;
    }


    public double area() {
        return 2 * PI * radius * radius + 2 * PI * radius * height;
    }

    public void setColor(String c) {
        this.color = c;
    }

    public void volume() {
        System.out.println("圆柱体积: " + PI * radius * radius * height);
    }
}
