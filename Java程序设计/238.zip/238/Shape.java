interface Shape extends Area, SetColor {
    void volume();
}
