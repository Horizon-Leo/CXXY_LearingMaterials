public class CylinderTest {
    public static void main(String[] args) {
        Cylinder cylinder = new Cylinder(3.0, 5.0, "Red");

        System.out.println("圆柱体面积: " + cylinder.area());
        System.out.println("圆柱体颜色: " + cylinder.color);

        cylinder.setColor("蓝色");
        System.out.println("更新圆柱体的颜色: " + cylinder.color);

        cylinder.volume();
    }
}