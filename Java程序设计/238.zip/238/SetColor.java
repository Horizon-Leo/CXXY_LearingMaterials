public interface SetColor {
    void setColor(String c);
}
