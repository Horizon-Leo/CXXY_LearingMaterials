public interface Area {
    double PI = 3.14;
    double area();
}
